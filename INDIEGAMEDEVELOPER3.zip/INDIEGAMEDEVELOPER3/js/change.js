<script type="text/javascript">
            var imgBg=document.getElementById("imgBg");
            imgBg.onclick=function(){
                imgBg.src="images/职能2.png"
            }